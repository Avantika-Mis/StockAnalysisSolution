﻿namespace TradeOrderBookPresentation
{
    partial class frmTrade
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpStocks = new System.Windows.Forms.GroupBox();
            this.grpGraphSection = new System.Windows.Forms.GroupBox();
            this.lblSecName = new System.Windows.Forms.Label();
            this.lblPrevLow = new System.Windows.Forms.Label();
            this.lblPrevHigh = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblStockName = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rchNewsFeeder = new System.Windows.Forms.RichTextBox();
            this.lblTrend = new System.Windows.Forms.Label();
            this.btnTrade = new System.Windows.Forms.Button();
            this.grpTradeBox = new System.Windows.Forms.GroupBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.userHoldingGrid = new System.Windows.Forms.DataGridView();
            this.pnlTrade = new System.Windows.Forms.Panel();
            this.btnPlaceOrder = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.lblCurrentStockHoldingCount = new System.Windows.Forms.Label();
            this.lblCurrentHoldings = new System.Windows.Forms.Label();
            this.radioSell = new System.Windows.Forms.RadioButton();
            this.radioBuy = new System.Windows.Forms.RadioButton();
            this.lblLoggedInUser = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtNumberOfShares = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblTotalAmountToBeInvested = new System.Windows.Forms.Label();
            this.SymbolName = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CountOfSecurity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ProfitOrLoss = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Investment = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label5 = new System.Windows.Forms.Label();
            this.lblBalanceAmountValue = new System.Windows.Forms.Label();
            this.grpStocks.SuspendLayout();
            this.grpGraphSection.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grpTradeBox.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.userHoldingGrid)).BeginInit();
            this.pnlTrade.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpStocks
            // 
            this.grpStocks.Controls.Add(this.grpGraphSection);
            this.grpStocks.Location = new System.Drawing.Point(12, 62);
            this.grpStocks.Name = "grpStocks";
            this.grpStocks.Size = new System.Drawing.Size(437, 176);
            this.grpStocks.TabIndex = 0;
            this.grpStocks.TabStop = false;
            // 
            // grpGraphSection
            // 
            this.grpGraphSection.Controls.Add(this.lblSecName);
            this.grpGraphSection.Controls.Add(this.lblPrevLow);
            this.grpGraphSection.Controls.Add(this.lblPrevHigh);
            this.grpGraphSection.Controls.Add(this.label2);
            this.grpGraphSection.Controls.Add(this.label1);
            this.grpGraphSection.Controls.Add(this.lblStockName);
            this.grpGraphSection.Location = new System.Drawing.Point(6, 21);
            this.grpGraphSection.Name = "grpGraphSection";
            this.grpGraphSection.Size = new System.Drawing.Size(404, 127);
            this.grpGraphSection.TabIndex = 1;
            this.grpGraphSection.TabStop = false;
            // 
            // lblSecName
            // 
            this.lblSecName.AutoSize = true;
            this.lblSecName.Location = new System.Drawing.Point(111, 31);
            this.lblSecName.Name = "lblSecName";
            this.lblSecName.Size = new System.Drawing.Size(44, 16);
            this.lblSecName.TabIndex = 5;
            this.lblSecName.Text = "label3";
            // 
            // lblPrevLow
            // 
            this.lblPrevLow.AutoSize = true;
            this.lblPrevLow.Location = new System.Drawing.Point(200, 94);
            this.lblPrevLow.Name = "lblPrevLow";
            this.lblPrevLow.Size = new System.Drawing.Size(0, 16);
            this.lblPrevLow.TabIndex = 4;
            // 
            // lblPrevHigh
            // 
            this.lblPrevHigh.AutoSize = true;
            this.lblPrevHigh.Location = new System.Drawing.Point(200, 66);
            this.lblPrevHigh.Name = "lblPrevHigh";
            this.lblPrevHigh.Size = new System.Drawing.Size(0, 16);
            this.lblPrevHigh.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(87, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Previous Low";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(91, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Previous High";
            // 
            // lblStockName
            // 
            this.lblStockName.AutoSize = true;
            this.lblStockName.Location = new System.Drawing.Point(13, 31);
            this.lblStockName.Name = "lblStockName";
            this.lblStockName.Size = new System.Drawing.Size(58, 16);
            this.lblStockName.TabIndex = 0;
            this.lblStockName.Text = "Security ";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rchNewsFeeder);
            this.groupBox1.Location = new System.Drawing.Point(468, 74);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(417, 164);
            this.groupBox1.TabIndex = 2;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Stock News";
            // 
            // rchNewsFeeder
            // 
            this.rchNewsFeeder.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.rchNewsFeeder.Location = new System.Drawing.Point(6, 21);
            this.rchNewsFeeder.Name = "rchNewsFeeder";
            this.rchNewsFeeder.Size = new System.Drawing.Size(405, 130);
            this.rchNewsFeeder.TabIndex = 0;
            this.rchNewsFeeder.Text = "";
            // 
            // lblTrend
            // 
            this.lblTrend.AutoSize = true;
            this.lblTrend.Location = new System.Drawing.Point(163, 236);
            this.lblTrend.Name = "lblTrend";
            this.lblTrend.Size = new System.Drawing.Size(43, 16);
            this.lblTrend.TabIndex = 3;
            this.lblTrend.Text = "Trend";
            // 
            // btnTrade
            // 
            this.btnTrade.Location = new System.Drawing.Point(885, 150);
            this.btnTrade.Name = "btnTrade";
            this.btnTrade.Size = new System.Drawing.Size(81, 38);
            this.btnTrade.TabIndex = 1;
            this.btnTrade.Text = "Trade";
            this.btnTrade.UseVisualStyleBackColor = true;
            this.btnTrade.Click += new System.EventHandler(this.btnTrade_Click);
            // 
            // grpTradeBox
            // 
            this.grpTradeBox.Controls.Add(this.groupBox3);
            this.grpTradeBox.Controls.Add(this.pnlTrade);
            this.grpTradeBox.Controls.Add(this.lblTrend);
            this.grpTradeBox.Location = new System.Drawing.Point(12, 250);
            this.grpTradeBox.Name = "grpTradeBox";
            this.grpTradeBox.Size = new System.Drawing.Size(1003, 318);
            this.grpTradeBox.TabIndex = 4;
            this.grpTradeBox.TabStop = false;
            this.grpTradeBox.Text = "Trade Box";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.userHoldingGrid);
            this.groupBox3.Location = new System.Drawing.Point(456, 21);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(535, 231);
            this.groupBox3.TabIndex = 4;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "User Portfolio";
            // 
            // userHoldingGrid
            // 
            this.userHoldingGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.userHoldingGrid.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.SymbolName,
            this.CountOfSecurity,
            this.ProfitOrLoss,
            this.Investment});
            this.userHoldingGrid.Location = new System.Drawing.Point(6, 21);
            this.userHoldingGrid.Name = "userHoldingGrid";
            this.userHoldingGrid.RowHeadersWidth = 51;
            this.userHoldingGrid.RowTemplate.Height = 24;
            this.userHoldingGrid.Size = new System.Drawing.Size(508, 116);
            this.userHoldingGrid.TabIndex = 0;
            // 
            // pnlTrade
            // 
            this.pnlTrade.Controls.Add(this.lblBalanceAmountValue);
            this.pnlTrade.Controls.Add(this.label5);
            this.pnlTrade.Controls.Add(this.groupBox2);
            this.pnlTrade.Controls.Add(this.btnPlaceOrder);
            this.pnlTrade.Controls.Add(this.comboBox1);
            this.pnlTrade.Controls.Add(this.radioSell);
            this.pnlTrade.Controls.Add(this.radioBuy);
            this.pnlTrade.Location = new System.Drawing.Point(6, 21);
            this.pnlTrade.Name = "pnlTrade";
            this.pnlTrade.Size = new System.Drawing.Size(421, 181);
            this.pnlTrade.TabIndex = 0;
            // 
            // btnPlaceOrder
            // 
            this.btnPlaceOrder.Location = new System.Drawing.Point(6, 120);
            this.btnPlaceOrder.Name = "btnPlaceOrder";
            this.btnPlaceOrder.Size = new System.Drawing.Size(99, 45);
            this.btnPlaceOrder.TabIndex = 7;
            this.btnPlaceOrder.Text = "Place Order";
            this.btnPlaceOrder.UseVisualStyleBackColor = true;
            this.btnPlaceOrder.Click += new System.EventHandler(this.btnPlaceOrder_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.AccessibleDescription = "cmbBuySellOptions";
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Market",
            "Limit",
            "Specific Value"});
            this.comboBox1.Location = new System.Drawing.Point(6, 54);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(136, 24);
            this.comboBox1.TabIndex = 6;
            // 
            // lblCurrentStockHoldingCount
            // 
            this.lblCurrentStockHoldingCount.AutoSize = true;
            this.lblCurrentStockHoldingCount.Location = new System.Drawing.Point(161, 18);
            this.lblCurrentStockHoldingCount.Name = "lblCurrentStockHoldingCount";
            this.lblCurrentStockHoldingCount.Size = new System.Drawing.Size(44, 16);
            this.lblCurrentStockHoldingCount.TabIndex = 5;
            this.lblCurrentStockHoldingCount.Text = "label3";
            // 
            // lblCurrentHoldings
            // 
            this.lblCurrentHoldings.AutoSize = true;
            this.lblCurrentHoldings.Location = new System.Drawing.Point(13, 18);
            this.lblCurrentHoldings.Name = "lblCurrentHoldings";
            this.lblCurrentHoldings.Size = new System.Drawing.Size(99, 16);
            this.lblCurrentHoldings.TabIndex = 4;
            this.lblCurrentHoldings.Text = "Current Holding";
            // 
            // radioSell
            // 
            this.radioSell.AutoSize = true;
            this.radioSell.Location = new System.Drawing.Point(63, 16);
            this.radioSell.Name = "radioSell";
            this.radioSell.Size = new System.Drawing.Size(51, 20);
            this.radioSell.TabIndex = 1;
            this.radioSell.Text = "Sell";
            this.radioSell.UseVisualStyleBackColor = true;
            // 
            // radioBuy
            // 
            this.radioBuy.AutoSize = true;
            this.radioBuy.Checked = true;
            this.radioBuy.Location = new System.Drawing.Point(6, 16);
            this.radioBuy.Name = "radioBuy";
            this.radioBuy.Size = new System.Drawing.Size(51, 20);
            this.radioBuy.TabIndex = 0;
            this.radioBuy.TabStop = true;
            this.radioBuy.Text = "Buy";
            this.radioBuy.UseVisualStyleBackColor = true;
            // 
            // lblLoggedInUser
            // 
            this.lblLoggedInUser.AutoSize = true;
            this.lblLoggedInUser.Location = new System.Drawing.Point(18, 20);
            this.lblLoggedInUser.Name = "lblLoggedInUser";
            this.lblLoggedInUser.Size = new System.Drawing.Size(44, 16);
            this.lblLoggedInUser.TabIndex = 5;
            this.lblLoggedInUser.Text = "label3";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblTotalAmountToBeInvested);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.label3);
            this.groupBox2.Controls.Add(this.txtNumberOfShares);
            this.groupBox2.Controls.Add(this.lblCurrentHoldings);
            this.groupBox2.Controls.Add(this.lblCurrentStockHoldingCount);
            this.groupBox2.Location = new System.Drawing.Point(171, 21);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(233, 144);
            this.groupBox2.TabIndex = 8;
            this.groupBox2.TabStop = false;
            // 
            // txtNumberOfShares
            // 
            this.txtNumberOfShares.Location = new System.Drawing.Point(161, 45);
            this.txtNumberOfShares.Name = "txtNumberOfShares";
            this.txtNumberOfShares.Size = new System.Drawing.Size(41, 22);
            this.txtNumberOfShares.TabIndex = 6;
            this.txtNumberOfShares.TextChanged += new System.EventHandler(this.txtNumberOfShares_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(117, 16);
            this.label3.TabIndex = 7;
            this.label3.Text = "Number Of Shares";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(13, 80);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(52, 16);
            this.label4.TabIndex = 8;
            this.label4.Text = "Amount";
            // 
            // lblTotalAmountToBeInvested
            // 
            this.lblTotalAmountToBeInvested.AutoSize = true;
            this.lblTotalAmountToBeInvested.Location = new System.Drawing.Point(157, 78);
            this.lblTotalAmountToBeInvested.Name = "lblTotalAmountToBeInvested";
            this.lblTotalAmountToBeInvested.Size = new System.Drawing.Size(44, 16);
            this.lblTotalAmountToBeInvested.TabIndex = 9;
            this.lblTotalAmountToBeInvested.Text = "label5";
            // 
            // SymbolName
            // 
            this.SymbolName.HeaderText = "Symbol Name";
            this.SymbolName.MinimumWidth = 6;
            this.SymbolName.Name = "SymbolName";
            this.SymbolName.Width = 125;
            // 
            // CountOfSecurity
            // 
            this.CountOfSecurity.HeaderText = "Holding Count";
            this.CountOfSecurity.MinimumWidth = 6;
            this.CountOfSecurity.Name = "CountOfSecurity";
            this.CountOfSecurity.Width = 125;
            // 
            // ProfitOrLoss
            // 
            this.ProfitOrLoss.HeaderText = "Profit/Loss";
            this.ProfitOrLoss.MinimumWidth = 6;
            this.ProfitOrLoss.Name = "ProfitOrLoss";
            this.ProfitOrLoss.Width = 125;
            // 
            // Investment
            // 
            this.Investment.HeaderText = "Invested";
            this.Investment.MinimumWidth = 6;
            this.Investment.Name = "Investment";
            this.Investment.Width = 125;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 95);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(57, 16);
            this.label5.TabIndex = 9;
            this.label5.Text = "Balance";
            // 
            // lblBalanceAmountValue
            // 
            this.lblBalanceAmountValue.AutoSize = true;
            this.lblBalanceAmountValue.Location = new System.Drawing.Point(94, 95);
            this.lblBalanceAmountValue.Name = "lblBalanceAmountValue";
            this.lblBalanceAmountValue.Size = new System.Drawing.Size(44, 16);
            this.lblBalanceAmountValue.TabIndex = 10;
            this.lblBalanceAmountValue.Text = "label6";
            // 
            // frmTrade
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(1027, 580);
            this.Controls.Add(this.lblLoggedInUser);
            this.Controls.Add(this.grpTradeBox);
            this.Controls.Add(this.btnTrade);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.grpStocks);
            this.Name = "frmTrade";
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.Text = "Trade Dashboard";
            this.Load += new System.EventHandler(this.frmTradeDashboard_Load);
            this.grpStocks.ResumeLayout(false);
            this.grpGraphSection.ResumeLayout(false);
            this.grpGraphSection.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.grpTradeBox.ResumeLayout(false);
            this.grpTradeBox.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.userHoldingGrid)).EndInit();
            this.pnlTrade.ResumeLayout(false);
            this.pnlTrade.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpStocks;
        private System.Windows.Forms.GroupBox grpGraphSection;
        private System.Windows.Forms.Label lblStockName;
        private System.Windows.Forms.Label lblPrevLow;
        private System.Windows.Forms.Label lblPrevHigh;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RichTextBox rchNewsFeeder;
        private System.Windows.Forms.Label lblTrend;
        private System.Windows.Forms.Button btnTrade;
        private System.Windows.Forms.GroupBox grpTradeBox;
        private System.Windows.Forms.Label lblSecName;
        private System.Windows.Forms.Panel pnlTrade;
        private System.Windows.Forms.RadioButton radioSell;
        private System.Windows.Forms.RadioButton radioBuy;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Label lblCurrentStockHoldingCount;
        private System.Windows.Forms.Label lblCurrentHoldings;
        private System.Windows.Forms.DataGridView userHoldingGrid;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Button btnPlaceOrder;
        public System.Windows.Forms.Label lblLoggedInUser;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label lblTotalAmountToBeInvested;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNumberOfShares;
        private System.Windows.Forms.DataGridViewTextBoxColumn SymbolName;
        private System.Windows.Forms.DataGridViewTextBoxColumn CountOfSecurity;
        private System.Windows.Forms.DataGridViewTextBoxColumn ProfitOrLoss;
        private System.Windows.Forms.DataGridViewTextBoxColumn Investment;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label lblBalanceAmountValue;
    }
}