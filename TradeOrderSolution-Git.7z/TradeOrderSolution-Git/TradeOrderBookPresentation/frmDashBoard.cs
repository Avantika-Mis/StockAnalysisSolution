﻿using ChartDirector;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TradeOrderBookPresentation.TradeBL;
using TradeOrderService;

namespace TradeOrderBookPresentation
{
    public partial class TradeOrderPresentation : Form
    {
        private ConcurrentDictionary<string, List<StockModel>> result = null;
        private frmTrade frmTradeDashBoard = null;

        public TradeOrderPresentation()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {

        }

        internal void PopulateStockView()
        {
            try
            {
                var proxy = WcfUtility.GetChannelFactory<ITrade>("http://localhost:4321/TradeService").CreateChannel();

                result = proxy.GetAllStocks();

                foreach (var stock in proxy.GetAllStocks().Keys)
                {
                    lstStockCollections.Items.Add(stock);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Services are not running !!  Inner Exception from Service Class" + ex.Message);
            }
        }

        private void lstStockCollections_Click(object sender, EventArgs e)
        {
            ShowChartAndMarketData();
        }

        private void TradeOrderPresentation_Load(object sender, EventArgs e)
        {
            PopulateStockView();

            GetNews();
        }

        private void ShowChartAndMarketData()
        {
            var resultDataForAGivenStock = result[lstStockCollections.SelectedItem.ToString()].ToList().Select(item => item.DailyLow).ToArray();

            XYChart c = new XYChart(250, 250);

            string[] labels = Helper.GetStringContent(result.Count());

            // Set the plotarea at (30, 20) and of size 200 x 200 pixels
            c.setPlotArea(30, 20, 200, 200);

            // Add a line chart layer using the given data
            c.addLineLayer(resultDataForAGivenStock);

            // Set the labels on the x axis.
            c.xAxis().setLabels(labels);

            // Display 1 out of 3 labels on the x-axis.
            c.xAxis().setLabelStep(3);

            // Output the chart
            stockChart.Chart = c;

            //include tool tip for the chart
            stockChart.ImageMap = c.getHTMLImageMap("clickable", "",
                "title='Hour {xLabel}: Traffic {value} GBytes'");
        }

        private void GetNews()
        {
            NewsFeeder news = new NewsFeeder();
            var resultNews = news.GetNewsThrougGoogleAPI("Indian Stock Market");

            StringBuilder newsBuilder = new StringBuilder();

            foreach (var item in resultNews)
            {
                newsBuilder.AppendLine(item.Title);

                newsBuilder.AppendLine("================================");

                rchNewsItems.Text = newsBuilder.ToString();
            }
        }

        private void btnAddStockToPortFolio_Click(object sender, EventArgs e)
        {
            if (lstStockCollections.SelectedItem == null)
            {
                MessageBox.Show("Kindly Select a stock to proceed for adding to portfolio");
                return;
            }

            frmTradeDashBoard = new frmTrade
            {
                StockInfo = result,
                SecurityName = lstStockCollections.SelectedItem.ToString()
            };

            frmTradeDashBoard.lblLoggedInUser.Text = "Welcome " + UserSessionManager.UserName;

            frmTradeDashBoard.Show();
            frmTradeDashBoard.Focus();
        }

        private void btnLogin_Click_1(object sender, EventArgs e)
        {
            frmSignUp frmSign = new frmSignUp();
            if (UserSessionManager.IsUserSessionLocked)
            {
                frmSign.btnLogin.Text = "LogOut";
                frmSign.grpLoginView.Enabled = false;
                
            }
            frmSign.Show();
        }
    }
}
