﻿using Newtonsoft.Json;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using TradeOrderBookPresentation.TradeBL;
using TradeOrderService;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.StartPanel;

namespace TradeOrderBookPresentation
{
    public partial class frmTrade : Form
    {
        internal string SecurityName { get; set; }
        internal ConcurrentDictionary<string, List<StockModel>> StockInfo { get; set; }
        internal double CurrentPriceOfStock { get; set; }

        public frmTrade()
        {
            InitializeComponent();
            grpTradeBox.Enabled = false;
        }

        private void frmTradeDashboard_Load(object sender, EventArgs e)
        {
            PrepareTradeOperation();
        }

        private void PrepareTradeOperation()
        {
            var resultDataForAGivenStock = StockInfo[SecurityName];

            lblPrevHigh.Text = resultDataForAGivenStock.Max(item => item.DailyHigh).ToString();
            lblPrevLow.Text = resultDataForAGivenStock.Min(item => item.DailyLow).ToString();
            CurrentPriceOfStock = Convert.ToDouble(resultDataForAGivenStock.LastOrDefault().DailyClose.ToString());

            NewsFeeder news = new NewsFeeder();
            var resultNews = news.GetNewsThrougGoogleAPI(SecurityName.Substring(0, SecurityName.IndexOf("XNSE") - 1));
            lblSecName.Text = SecurityName.Substring(0, SecurityName.IndexOf("XNSE") - 1);
            StringBuilder newsBuilder = new StringBuilder();

            foreach (var item in resultNews)
            {
                newsBuilder.AppendLine(item.Title);

                newsBuilder.AppendLine("================================");

                rchNewsFeeder.Text = newsBuilder.ToString();
            }
        }

        private void btnTrade_Click(object sender, EventArgs e)
        {
            MarketSentimentAnalysis();

            if (!UserSessionManager.IsUserSessionLocked)
            {
                MessageBox.Show("Kindly login if existing user to continue Trade!!");
            }
            else
            {
                grpTradeBox.Enabled = true;
                FetchHoldingsForTheCurrentUser();
            }
        }

        private void MarketSentimentAnalysis()
        {
            if (!rchNewsFeeder.Text.Contains("Loss"))
            {
                lblTrend.BackColor = Color.LightSeaGreen;
                lblTrend.Text = "Safe to Trade";
            }
            else
            {
                lblTrend.BackColor = Color.OrangeRed;
                lblTrend.Text = "Do not proceed to buy";
            }
        }

        private void FetchHoldingsForTheCurrentUser()
        {
            var proxy = WcfUtility.GetChannelFactory<IUserTradeService>("http://localhost:4323/UserTradeService").CreateChannel();

            UpdateUserHoldings(proxy.FetchHoldingsForTheCurrentUser(UserSessionManager.UserName));
        }

        private void btnPlaceOrder_Click(object sender, EventArgs e)
        {
            var proxy = WcfUtility.GetChannelFactory<IUserTradeService>("http://localhost:4323/UserTradeService").CreateChannel();
            int totalNumberOfShares = Convert.ToInt32(txtNumberOfShares.Text);
            int totalAmountToBeInvested = Convert.ToInt32(lblTotalAmountToBeInvested.Text);

            var result = proxy.StoreTradeForStockForUser(SecurityName, CurrentPriceOfStock.ToString(), UserSessionManager.UserName, radioBuy.Checked ? "Buy" : "Sell", totalNumberOfShares, totalAmountToBeInvested);

            if (result.IsTradeRejected)
            {
                MessageBox.Show("Trade is rejected due to low balance");
                return;
            }

            UpdateUserHoldings(result);
        }

        private void UpdateUserHoldings(UserTradeModel userTrade)
        {
            BindingSource binding = new BindingSource
            {
                DataSource = userTrade.Stocks
            };
            userHoldingGrid.DataSource = binding;
            lblBalanceAmountValue.Text = userTrade.TotalAmountWithUser.ToString();
        }

        private void txtNumberOfShares_TextChanged(object sender, EventArgs e)
        {
            try
            {
                lblTotalAmountToBeInvested.Text = (Convert.ToInt32(txtNumberOfShares.Text) * Convert.ToInt32(CurrentPriceOfStock)).ToString();

                lblBalanceAmountValue.Text = (Convert.ToInt32(lblBalanceAmountValue.Text) - (Convert.ToInt32(txtNumberOfShares.Text) * Convert.ToInt32(CurrentPriceOfStock))).ToString();
            }
            catch
            {

            }
        }
    }
}
