﻿using System;
using System.Windows.Forms;
using TradeOrderBookPresentation.TradeBL;
using TradeOrderService;

namespace TradeOrderBookPresentation
{
    public partial class frmSignUp : Form
    {
        public frmSignUp()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            var proxy = WcfUtility.GetChannelFactory<IRegistrationService>("http://localhost:4322/UserService").CreateChannel();

            var result = proxy.SignExistingUserToSystem(new TradeOrderService.Models.UserModel
            {
                UserName = txtUserName.Text,
                Password = txtPassword.Text
            });
            if (!result)
            {
                MessageBox.Show("INVALID USER.. THE USER DOES NOT EXIST");
            }
            else
            {
                UserSessionManager.IsUserSessionLocked = true;
                UserSessionManager.UserName = txtUserName.Text;
               
                this.Close();
            }
        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            grpRegisterUser.Visible = true;
            btnRegister.Enabled = false;
            btnLogin.Enabled = false;
        }

        private void btnCreateUser_Click(object sender, EventArgs e)
        {
            if (txtRegisterPassword.Text == txtRegisterConfirmPassword.Text)
            {
                var proxy = WcfUtility.GetChannelFactory<IRegistrationService>("http://localhost:4322/UserService").CreateChannel();

                var result = proxy.RegisterUser(new TradeOrderService.Models.UserModel
                {
                    AccountId = txtAccountId.Text,
                    PanId = txtPanId.Text,
                    Password = txtRegisterPassword.Text,
                    UserName = txtRegisterUserName.Text
                });

                if (result == "SUCCESS")
                {
                    MessageBox.Show("User is Successfully created");
                    grpRegisterUser.Visible = false;
                    btnLogin.Enabled = true;
                }
                else
                {
                    MessageBox.Show("There was an issue with user registration");
                }
            }
            else
            {
                MessageBox.Show("Password and Confirm Password is not matching.! Please enter valid credentials");
            }
        }
    }
}
