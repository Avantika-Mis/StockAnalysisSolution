﻿using System;
using System.Configuration;
using System.ServiceModel;
using System.ServiceModel.Description;

namespace TradeOrderBookPresentation.TradeBL
{

    public static class WcfUtility
    {
        #region Constants
        private const int WcfSerializerMaxStringContentLength = (16 * 1024 * 1024); //16MB;
        private const int WcfSerializerMaxArrayLength = 65535; //16bit
        private const int WcfSerializerMaxBytesPerRead = (16 * 1024 * 1024); //16MB
        private const int WcfSerializerMaxDepth = 65535; //16bit;
        private const int WcfSerializerMaxNameTableCharCount = 16384; //default 16K
        #endregion

        #region Factory Generator (GetChannelFactory<T>)
        /// <summary>
        /// Gets a channel factory for the given service type
        /// </summary>
        /// <summary>Retrieves a WCF Client for the T interface.</summary>
        /// <typeparam name="T">The Interface the WCF Service Implements</typeparam>
        /// <param name="serviceEndpointUrl">Optional URL for the service Endpoint. Will use an application setting of "SERVICE_URL:Full.Namespace.For.T" by default.</param>
        /// <returns>An instance of the Interface T as a WCF Client.</returns>
    
        public static ChannelFactory<T> GetChannelFactory<T>(string serviceEndpointUrl = null)
        {
            //no serviceEndpontUrl specified
            if (string.IsNullOrWhiteSpace(serviceEndpointUrl))
            {
                //get default from config appsettings
                var configSetting = string.Format("SERVICE_URL:{0}", (typeof(T)).FullName);
                serviceEndpointUrl = ConfigurationManager.AppSettings[configSetting];

                if (string.IsNullOrWhiteSpace(serviceEndpointUrl))
                {
                    //no appsetting, throw exception.
                    throw new ApplicationException(string.Format("Missing Application Setting for '{0}'", configSetting));
                }
            }

            var endpoint = new EndpointAddress(serviceEndpointUrl);

            //http/https binding
            if (serviceEndpointUrl.StartsWith("http://") || serviceEndpointUrl.StartsWith("https://"))
            {
                var binding = new WSHttpBinding();

                //raise binding reader quotas to sane limits
                binding.ReaderQuotas.MaxStringContentLength = WcfSerializerMaxStringContentLength;
                binding.ReaderQuotas.MaxArrayLength = WcfSerializerMaxArrayLength;
                binding.ReaderQuotas.MaxBytesPerRead = WcfSerializerMaxBytesPerRead;
                binding.ReaderQuotas.MaxDepth = WcfSerializerMaxDepth;
                binding.ReaderQuotas.MaxNameTableCharCount = WcfSerializerMaxNameTableCharCount;
                binding.MaxReceivedMessageSize = WcfSerializerMaxBytesPerRead;

                var factory = new ChannelFactory<T>(binding, endpoint);
                
                return factory;
            }

            //tcp binding
            if (serviceEndpointUrl.StartsWith("net.tcp://"))
            {
                var binding = new NetTcpBinding();

                //raise binding reader quotas to sane limits
                binding.ReaderQuotas.MaxStringContentLength = WcfSerializerMaxStringContentLength;
                binding.ReaderQuotas.MaxArrayLength = WcfSerializerMaxArrayLength;
                binding.ReaderQuotas.MaxBytesPerRead = WcfSerializerMaxBytesPerRead;
                binding.ReaderQuotas.MaxDepth = WcfSerializerMaxDepth;
                //binding.ReaderQuotas.MaxNameTableCharCount = WcfSerializerMaxNameTableCharCount;

                var factory = new ChannelFactory<T>(binding, endpoint);
                return factory;
            }

            //local net pipes binding
            if (serviceEndpointUrl.StartsWith("net.pipe://"))
            {
                var binding = new NetNamedPipeBinding();

                //raise binding reader quotas to sane limits
                binding.ReaderQuotas.MaxStringContentLength = WcfSerializerMaxStringContentLength;
                binding.ReaderQuotas.MaxArrayLength = WcfSerializerMaxArrayLength;
                binding.ReaderQuotas.MaxBytesPerRead = WcfSerializerMaxBytesPerRead;
                binding.ReaderQuotas.MaxDepth = WcfSerializerMaxDepth;
                //binding.ReaderQuotas.MaxNameTableCharCount = WcfSerializerMaxNameTableCharCount;

                var factory = new ChannelFactory<T>(binding, endpoint);
                return factory;
            }

            //no matching binding for the config
            throw new ApplicationException(string.Format("The service end point url specified does not match a supported protocol ({0}).", serviceEndpointUrl));
        }
        #endregion


    }
}
