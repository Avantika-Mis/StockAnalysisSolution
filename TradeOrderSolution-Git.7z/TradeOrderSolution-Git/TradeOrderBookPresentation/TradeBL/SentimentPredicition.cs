﻿using Microsoft.ML;
using Microsoft.ML.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TradeOrderBookPresentation.TradeBL
{
    internal class SentimentPredicition
    {
        public void GetSentiment(string dataContent)
        {
            var mlContext = new MLContext(seed: 1);
            string dataPath = @"E:\Saurav\Code-Poc\Stock Market  API Code\Project-Initial\Trade Order Solution\TradeOrderSolution\TradeOrderBookPresentation\Training Data\TrainingData.txt";

            //var classifier = new GroupDocs.Classification.SentimentClassifier();
            //var sentimentPositivity = sentiments.Select(x => classifier.PositiveProbability(x)).ToArray();
            //Console.WriteLine(string.Join("\\n", sentimentPositivity));
        }
    }

    public class SentimentIssue
    {
        [LoadColumn(0)]
        public bool Label { get; set; }
        [LoadColumn(1)]
        public string Text { get; set; }
    }

    public class SentimentPrediction
    {
        [ColumnName("PredictedLabel")]
        public bool Prediction { get; set; }
        public float Probability { get; set; }
        public float Score { get; set; }
    }

}
