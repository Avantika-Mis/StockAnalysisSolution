﻿namespace TradeOrderBookPresentation.TradeBL
{
    internal static class Helper
    {
        internal static string[] GetStringContent(int v)
        {
            string[] result = new string[v / 50];

            for (int i = 0; i < v / 50; i++)
            {
                result[i] = i.ToString();
            }

            return result;
        }
    }
}
