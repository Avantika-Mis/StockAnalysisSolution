﻿using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Net;
using System.Text;
using TradeOrderService;

namespace TradeOrderBookPresentation.TradeBL
{
    internal class NewsFeeder
    {
        internal ItemNews[] GetNewsThrougGoogleAPI(string stockName)
        {
            List<ItemNews> Details = new List<ItemNews>();

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create
            ("http://news.google.com/news?q=" + stockName + "&output=rss");

            //Method GET
            request.Method = "GET";

            //HttpWebResponse for result
            HttpWebResponse response = (HttpWebResponse)request.GetResponse();


            //Mapping of status code
            if (response.StatusCode == HttpStatusCode.OK)
            {
                Stream receiveStream = response.GetResponseStream();
                StreamReader readStream;
                if (response.CharacterSet == "")
                    readStream = new StreamReader(receiveStream);
                else
                    readStream = new StreamReader(receiveStream, Encoding.GetEncoding(response.CharacterSet));

                //Get news data in json string

                string data = readStream.ReadToEnd();

                //Declare DataSet for putting data in it.
                DataSet ds = new DataSet();
                StringReader reader = new StringReader(data);
                ds.ReadXml(reader);
                _ = new DataTable();

                if (ds.Tables.Count > 3)
                {
                    DataTable dtGetNews = ds.Tables["item"];

                    foreach (DataRow dtRow in dtGetNews.Rows)
                    {
                        ItemNews DataObj = new ItemNews();
                        DataObj.Title = dtRow["title"].ToString();
                        DataObj.Link = dtRow["link"].ToString();
                        DataObj.Item_id = dtRow["item_id"].ToString();
                        DataObj.PubDate = dtRow["pubDate"].ToString();
                        DataObj.Description = dtRow["description"].ToString();
                        Details.Add(DataObj);
                    }
                }
            }
            //Return News array 
            return Details.ToArray();
        }
    }
}
