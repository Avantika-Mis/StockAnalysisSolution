﻿namespace TradeOrderBookPresentation.TradeBL
{
    public static class UserSessionManager
    {
        public static bool IsUserSessionLocked = false;
        public static string UserName { get; set; }
    }
}
