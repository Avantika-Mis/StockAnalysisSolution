﻿namespace TradeOrderBookPresentation
{
    partial class TradeOrderPresentation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(TradeOrderPresentation));
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lstStockCollections = new System.Windows.Forms.ListBox();
            this.grpTrend = new System.Windows.Forms.GroupBox();
            this.stockChart = new ChartDirector.WinChartViewer();
            this.grpNews = new System.Windows.Forms.GroupBox();
            this.rchNewsItems = new System.Windows.Forms.RichTextBox();
            this.btnAddStockToPortFolio = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnLogin = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.grpTrend.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.stockChart)).BeginInit();
            this.grpNews.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox2
            // 
            this.groupBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("groupBox2.BackgroundImage")));
            this.groupBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.groupBox2.Controls.Add(this.lstStockCollections);
            this.groupBox2.Location = new System.Drawing.Point(12, 40);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(441, 466);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Stocks In Sight";
            // 
            // lstStockCollections
            // 
            this.lstStockCollections.BackColor = System.Drawing.SystemColors.Highlight;
            this.lstStockCollections.FormattingEnabled = true;
            this.lstStockCollections.ItemHeight = 16;
            this.lstStockCollections.Location = new System.Drawing.Point(6, 21);
            this.lstStockCollections.Name = "lstStockCollections";
            this.lstStockCollections.Size = new System.Drawing.Size(429, 420);
            this.lstStockCollections.TabIndex = 0;
            this.lstStockCollections.Click += new System.EventHandler(this.lstStockCollections_Click);
            // 
            // grpTrend
            // 
            this.grpTrend.BackColor = System.Drawing.Color.MediumBlue;
            this.grpTrend.Controls.Add(this.stockChart);
            this.grpTrend.Location = new System.Drawing.Point(534, 28);
            this.grpTrend.Name = "grpTrend";
            this.grpTrend.Size = new System.Drawing.Size(358, 240);
            this.grpTrend.TabIndex = 2;
            this.grpTrend.TabStop = false;
            this.grpTrend.Text = "Trend Data";
            // 
            // stockChart
            // 
            this.stockChart.BackColor = System.Drawing.Color.LightSkyBlue;
            this.stockChart.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("stockChart.BackgroundImage")));
            this.stockChart.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.stockChart.Location = new System.Drawing.Point(15, 21);
            this.stockChart.Name = "stockChart";
            this.stockChart.Size = new System.Drawing.Size(325, 194);
            this.stockChart.TabIndex = 0;
            this.stockChart.TabStop = false;
            this.stockChart.WaitOnLoad = true;
            // 
            // grpNews
            // 
            this.grpNews.BackColor = System.Drawing.Color.Blue;
            this.grpNews.Controls.Add(this.rchNewsItems);
            this.grpNews.Location = new System.Drawing.Point(534, 274);
            this.grpNews.Name = "grpNews";
            this.grpNews.Size = new System.Drawing.Size(513, 234);
            this.grpNews.TabIndex = 3;
            this.grpNews.TabStop = false;
            this.grpNews.Text = "Market News";
            // 
            // rchNewsItems
            // 
            this.rchNewsItems.Font = new System.Drawing.Font("Perpetua Titling MT", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rchNewsItems.Location = new System.Drawing.Point(25, 21);
            this.rchNewsItems.Name = "rchNewsItems";
            this.rchNewsItems.ReadOnly = true;
            this.rchNewsItems.Size = new System.Drawing.Size(468, 193);
            this.rchNewsItems.TabIndex = 0;
            this.rchNewsItems.Text = "";
            // 
            // btnAddStockToPortFolio
            // 
            this.btnAddStockToPortFolio.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAddStockToPortFolio.BackgroundImage")));
            this.btnAddStockToPortFolio.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddStockToPortFolio.Font = new System.Drawing.Font("SH-Bree-Headline", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddStockToPortFolio.ForeColor = System.Drawing.SystemColors.Control;
            this.btnAddStockToPortFolio.Location = new System.Drawing.Point(906, 132);
            this.btnAddStockToPortFolio.Name = "btnAddStockToPortFolio";
            this.btnAddStockToPortFolio.Size = new System.Drawing.Size(141, 63);
            this.btnAddStockToPortFolio.TabIndex = 4;
            this.btnAddStockToPortFolio.Text = "Add To Portfolio";
            this.btnAddStockToPortFolio.TextImageRelation = System.Windows.Forms.TextImageRelation.TextBeforeImage;
            this.btnAddStockToPortFolio.UseVisualStyleBackColor = true;
            this.btnAddStockToPortFolio.Click += new System.EventHandler(this.btnAddStockToPortFolio_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Green;
            this.groupBox1.Controls.Add(this.btnLogin);
            this.groupBox1.ForeColor = System.Drawing.Color.Navy;
            this.groupBox1.Location = new System.Drawing.Point(906, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(141, 85);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            // 
            // btnLogin
            // 
            this.btnLogin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnLogin.BackgroundImage")));
            this.btnLogin.Font = new System.Drawing.Font("Microsoft YaHei", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLogin.Location = new System.Drawing.Point(18, 16);
            this.btnLogin.Name = "btnLogin";
            this.btnLogin.Size = new System.Drawing.Size(105, 57);
            this.btnLogin.TabIndex = 0;
            this.btnLogin.Text = "Login / Register";
            this.btnLogin.UseVisualStyleBackColor = true;
            this.btnLogin.Click += new System.EventHandler(this.btnLogin_Click_1);
            // 
            // TradeOrderPresentation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1062, 524);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnAddStockToPortFolio);
            this.Controls.Add(this.grpNews);
            this.Controls.Add(this.grpTrend);
            this.Controls.Add(this.groupBox2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "TradeOrderPresentation";
            this.Text = "Bull Stock";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.TradeOrderPresentation_Load);
            this.groupBox2.ResumeLayout(false);
            this.grpTrend.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.stockChart)).EndInit();
            this.grpNews.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.ListBox lstStockCollections;
        private System.Windows.Forms.GroupBox grpTrend;
        private ChartDirector.WinChartViewer stockChart;
        private System.Windows.Forms.GroupBox grpNews;
        private System.Windows.Forms.RichTextBox rchNewsItems;
        private System.Windows.Forms.Button btnAddStockToPortFolio;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnLogin;
    }
}

