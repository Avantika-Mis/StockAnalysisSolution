﻿using Newtonsoft.Json.Linq;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;

namespace TradeOrderService
{
    public class TradeAPIConsumer
    {
        private readonly string apiKey = "033715ec83e67c3411dc48ed29131974";
        private readonly string filePath = ConfigurationManager.AppSettings["ResourcePath"] + @"\Resources\Market Data";

        /// <summary>
        /// Get the market Data from local market data path.
        /// </summary>
        /// <param name="symbolName"></param>
        /// <returns></returns>
        public List<StockModel> GetStockReaLTimeInfoFromLocal(string symbolName)
        {
            string[] files = Directory.GetFiles(Path.Combine(filePath));
            string fileToRead = files.ToList().Where(item => Path.GetFileName(item).Equals(symbolName + ".txt")).Select(item => item).FirstOrDefault();

            using (StreamReader reader = new StreamReader(fileToRead))
            {
                string contentFromMarketDataFile = reader.ReadToEnd();
                return ParseQueryData(contentFromMarketDataFile);
            }
        }

        public List<StockModel> GetStockRealTimeInfoFromMarket(string symbolName)
        {
            string QUERY_URL = $"http://api.marketstack.com/v1/";

            var client = new RestClient(QUERY_URL);

            var request = new RestRequest($"eod?access_key={apiKey}&symbols={symbolName}&date_from=2022-01-01&date_to=2022-11-14");

            var queryResult = client.Execute(request);

            // Store the values in the local file repository. This would help in case if the application needs to be run offline
            // The market data would then be made readily available. 
            // The market data would not need to be latest provided the machine learning algo needed to parse and predict the 
            // market trend would be sufficiently work even if the data is not latest.

            StoreMarketDataToLocalFile(symbolName, queryResult.Content);

            return ParseQueryData(queryResult.Content);
        }


        /// <summary>
        /// Store the market data over the local file.
        /// </summary>
        /// <param name="symbolName"></param>
        /// <param name="content"></param>
        /// <exception cref="NotImplementedException"></exception>
        private void StoreMarketDataToLocalFile(string symbolName, string content)
        {
            string fileName = @"E:\Saurav\Code-Poc\Stock Market  API Code\Project-Initial\Trade Order Solution\TradeOrderSolution\Resources\Market Data\" + symbolName + ".txt";

            using (StreamWriter writer = new StreamWriter(fileName))
            {
                writer.WriteLine(content);
                writer.Flush();
                writer.Close();
            }
        }

        private List<StockModel> ParseQueryData(string content)
        {
            List<StockModel> stockCollection = new List<StockModel>();

            JObject rss = JObject.Parse(content);
            for (int _count = 0; _count < rss["data"].Count(); _count++)
            {
                stockCollection.Add(new StockModel
                {
                    DailyOpen = Convert.ToDouble(rss["data"][_count]["open"]),
                    DailyClose = Convert.ToDouble(rss["data"][_count]["close"].ToString()),
                    DailyHigh = Convert.ToDouble(rss["data"][_count]["high"].ToString()),
                    DailyLow = Convert.ToDouble(rss["data"][_count]["low"].ToString()),
                });
            }
            return stockCollection;
        }
    }
}
