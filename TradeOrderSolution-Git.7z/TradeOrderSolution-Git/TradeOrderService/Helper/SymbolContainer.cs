﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TradeOrderService.Helper
{
    internal class SymbolContainer
    {
        public static List<string> GetAllSymbols()
        {
            return new List<string>
            {
                "SBIN.XNSE",
                "POWERGRID.XNSE",
                "HCLTECH.XNSE",
                "HCL_INSYS.XNSE",
                "HCL-INSYS.XNSE",
                "TCS.XNSE",
                "IEX.XNSE",
                "HINDUNILVR.XNSE",
                "HINDZINC.XNSE",
                "HAL.XNSE",
                "HINDCOPPER.XNSE",
                "HNDFDS.XNSE",
                "HCC.XNSE",
                "HINDOILEXP.XNSE",
                "HMVL.XNSE",
                "HINDCOMPOS.XNSE",
                "HINDMOTORS.XNSE",
                "HINDPETRO.XNSE",
                "IOC.XNSE",
                "IRCTC.XNSE",
                "INDHOTEL.XNSE",
                "IOB.XNSE",
                "ITI.XNSE",
                "INDIANB.XNSE",
                "NDIANHUME.XNSE",
                "IMFA.XNSE",
                "INDTERRAIN.XNSE",
                "INDIANCARD.XNSE",
                "IRFC.XNSE",
                "HDFCBANK.XNSE",
                "HDFC.XNSE"
            };
        }
    }
}
