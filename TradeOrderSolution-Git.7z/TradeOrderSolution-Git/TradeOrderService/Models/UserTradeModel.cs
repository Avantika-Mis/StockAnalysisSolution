﻿using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace TradeOrderService
{
    [DataContract]
    [KnownType(typeof(StockTradeModel))]
    public class UserTradeModel
    {
        [DataMember]
        public List<StockTradeModel> Stocks { get; set; }
        [DataMember]
        public bool IsTradeRejected { get; set; }
        [DataMember]
        public int AmountInvested { get; set; }

        [DataMember]
        public int TotalAmountWithUser { get; set; }
    }
}
