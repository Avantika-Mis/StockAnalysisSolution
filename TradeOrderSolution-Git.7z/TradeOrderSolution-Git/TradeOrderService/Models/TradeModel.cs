﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace TradeOrderService
{

    [DataContract]
    [KnownType(typeof(StockTradeModel))]
    public class StockContainer
    {
        [DataMember]
        public static ConcurrentDictionary<string, List<StockModel>> TradeCollection = null;

        private StockContainer() { }

        static StockContainer()
        {
            if (TradeCollection == null)
                TradeCollection = new ConcurrentDictionary<string, List<StockModel>>();
        }
    }

    [DataContract]
    public class StockModel
    {
        [DataMember]
        public string SymbolName { get; set; }
        [DataMember]
        public double DailyHigh { get; set; }
        [DataMember]
        public double DailyLow { get; set; }
        [DataMember]
        public double DailyOpen { get; set; }
        [DataMember]
        public double DailyClose { get; set; }
        [DataMember]
        public double DailyVolume { get; set; }
    }

    [DataContract]
    public class StockTradeModel : StockgTradeBaseModel
    {
        [DataMember]
        public string CurrentPrice { get; set; }
        [DataMember]
        public int HoldingCount { get; set; }

        [DataMember]
        public int ProfitLossVariable { get; set; }       
    }

    [DataContract]
    public class StockgTradeBaseModel
    {
        [DataMember]
        public string StockName { get; set; }

        [DataMember]
        public string Direction { get; set; }
    }


    [DataContract]
    [Flags]
    public enum Exchange
    {
        [EnumMember]
        NSE,
        [EnumMember]
        BSE
    }


    [DataContract]
    [Flags]
    public enum ProductClassType
    {
        [EnumMember]
        Futures,
        [EnumMember]
        Options,
        [EnumMember]
        Combination,
        [EnumMember]
        SpotOption,
    };


    public class ItemNews
    {
        public string Title { get; set; }
        public string Link { get; set; }
        public string Item_id { get; set; }
        public string PubDate { get; set; }
        public string Description { get; set; }
    }
}
