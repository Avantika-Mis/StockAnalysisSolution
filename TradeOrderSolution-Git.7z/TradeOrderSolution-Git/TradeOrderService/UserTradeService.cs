﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;

namespace TradeOrderService
{
    public class UserTradeService : IUserTradeService
    {
        public UserTradeModel FetchHoldingsForTheCurrentUser(string userName)
        {
            string tradeActivityFilePath, userTradeActivityFile;
            UserTradeModel userTrade;
            GetUserTradeInfoFilePath(userName, out tradeActivityFilePath, out userTradeActivityFile);

            if (File.Exists(Path.Combine(tradeActivityFilePath, userTradeActivityFile)))
            {
                userTrade = JsonConvert.DeserializeObject<UserTradeModel>(File.ReadAllText(Path.Combine(tradeActivityFilePath, userTradeActivityFile)));
            }
            else
            {
                userTrade = new UserTradeModel
                {
                    TotalAmountWithUser = 10000,
                    Stocks = new List<StockTradeModel> { }
                };
                File.WriteAllText(Path.Combine(tradeActivityFilePath, userTradeActivityFile), JsonConvert.SerializeObject(userTrade));
            }
            return userTrade;
        }

        /// <summary>
        /// Store the trade information to local storage.
        /// </summary>
        /// <param name="stockName"></param>
        /// <param name="currentPriceOfStock"></param>
        /// <param name="holdingCount"></param>
        /// <param name="userName"></param>
        /// <param name="directionOfPurchase"></param>
        /// <returns></returns>
        public UserTradeModel StoreTradeForStockForUser(string stockName, string currentPriceOfStock, string userName, string directionOfPurchase, int holdingCount, int amountInvested)
        {
            string tradeActivityFilePath, userTradeActivityFile;
            UserTradeModel userTrade;
            GetUserTradeInfoFilePath(userName, out tradeActivityFilePath, out userTradeActivityFile);
            string tradeActivityFile = Path.Combine(tradeActivityFilePath, userTradeActivityFile);
            StockTradeModel stockToUpdate = null;
            if (File.Exists(tradeActivityFile))
            {
                userTrade = JsonConvert.DeserializeObject<UserTradeModel>(File.ReadAllText(tradeActivityFile));

                stockToUpdate = userTrade.Stocks.Where(item => item.StockName == stockName).FirstOrDefault();

                if (stockToUpdate == null)
                {
                    stockToUpdate = new StockTradeModel
                    {
                        CurrentPrice = currentPriceOfStock,
                        Direction = directionOfPurchase,
                        StockName = stockName,
                        ProfitLossVariable = 0
                    };
                }

                if (!UpadateHoldingAndPriceForStock(currentPriceOfStock, directionOfPurchase, holdingCount, userTrade, stockToUpdate))
                {
                    userTrade.IsTradeRejected = true;
                }
            }
            else
            {
                userTrade = CreateUserTradeModel(stockName, currentPriceOfStock, directionOfPurchase);

                if (!UpadateHoldingAndPriceForStock(currentPriceOfStock, directionOfPurchase, holdingCount, userTrade, stockToUpdate))
                {
                    userTrade.IsTradeRejected = true;
                }
            }

            if (!userTrade.IsTradeRejected)
            {
                userTrade.Stocks.Add(stockToUpdate);
                File.WriteAllText(Path.Combine(tradeActivityFilePath, userTradeActivityFile), JsonConvert.SerializeObject(userTrade));
            }

            return userTrade;
        }

        private static UserTradeModel CreateUserTradeModel(string stockName, string currentPriceOfStock, string directionOfPurchase)
        {
            UserTradeModel userTrade = new UserTradeModel
            {
                Stocks = new List<StockTradeModel>()
            };
            StockTradeModel stock = new StockTradeModel
            {
                CurrentPrice = currentPriceOfStock,
                Direction = directionOfPurchase,
                StockName = stockName,
                ProfitLossVariable = 0
            };
            return userTrade;
        }

        private static bool UpadateHoldingAndPriceForStock(string currentPriceOfStock, string directionOfPurchase, int holdingCount, UserTradeModel userTrade, StockTradeModel stockTrade)
        {
            if (userTrade.TotalAmountWithUser < Convert.ToDouble(currentPriceOfStock) * holdingCount && directionOfPurchase.ToUpper() == "BUY")
            {
                return false;
            }
            else
            {
                if (directionOfPurchase.ToUpper() == "BUY")
                {
                    stockTrade.HoldingCount += holdingCount;
                    userTrade.AmountInvested += (int)(Convert.ToDouble(currentPriceOfStock) * holdingCount);
                    userTrade.TotalAmountWithUser -= (int)(Convert.ToDouble(currentPriceOfStock) * holdingCount);
                }
                else
                {
                    stockTrade.HoldingCount -= holdingCount;
                    userTrade.AmountInvested -= (int)(Convert.ToDouble(currentPriceOfStock) * holdingCount);
                    userTrade.TotalAmountWithUser += (int)(Convert.ToDouble(currentPriceOfStock) * holdingCount);
                }
            }
            return true;
        }

        private static void GetUserTradeInfoFilePath(string userName, out string tradeActivityFilePath, out string userTradeActivityFile)
        {
            tradeActivityFilePath = ConfigurationManager.AppSettings["ResourcePath"] + @"\Resources\User Data\User Trade Data";
            userTradeActivityFile = userName + ".json";
        }
    }
}
