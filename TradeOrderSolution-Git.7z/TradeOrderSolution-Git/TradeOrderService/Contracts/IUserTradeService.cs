﻿using Microsoft.SqlServer.Server;
using System.ServiceModel;

namespace TradeOrderService
{
    [ServiceContract]
    public interface IUserTradeService
    {
        [OperationContract]
        UserTradeModel StoreTradeForStockForUser(string stockName, string currentPriceOfStock, string userName, string directionOfPurchase, int holdingCount, int amountInvested);
        [OperationContract]
        UserTradeModel FetchHoldingsForTheCurrentUser(string userName);
    }
}
