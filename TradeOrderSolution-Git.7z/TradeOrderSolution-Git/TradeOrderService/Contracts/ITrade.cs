﻿using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ServiceModel;

namespace TradeOrderService
{
    [ServiceContract]
    public interface ITrade
    {
        [OperationContract]
        void FillStockInfo();

        [OperationContract]
        ConcurrentDictionary<string, List<StockModel>> GetAllStocks();
    }
}
