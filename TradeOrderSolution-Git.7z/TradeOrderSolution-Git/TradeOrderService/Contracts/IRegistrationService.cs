﻿using System.ServiceModel;
using TradeOrderService.Models;

namespace TradeOrderService
{
    [ServiceContract]
    public interface IRegistrationService
    {
        [OperationContract]
        string RegisterUser(UserModel user);
       
        [OperationContract]
        bool SignExistingUserToSystem(UserModel user);
    }
}
