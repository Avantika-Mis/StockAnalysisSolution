﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using TradeOrderService.Models;

namespace TradeOrderService
{
    public class UserService : IRegistrationService
    {
        #region Documentation for each method

        // Read the User Profile Data stored locally in the system.
        // If the input user matches to that of the content stored in the file
        // User gets successfully logged in.

        // The activity of the user performing trade would then be stored in usertradeactivity
        // file specific to each user. The userActivity file would contain userId in the file name. The file in the mean time would store trade transactional data.

        #endregion


        public string RegisterUser(UserModel user)
        {
            string userProfilePath = ConfigurationManager.AppSettings["ResourcePath"] + @"\Resources\User Data\Profile\" + "UserProfiles.json";

            if (File.Exists(userProfilePath))
            {
                if (CheckIfUserExist(user.UserName, user.Password) == "NOTEXIST")
                {
                    string userProfileContent = File.ReadAllText(ConfigurationManager.AppSettings["ResourcePath"] + @"\Resources\User Data\Profile\" + "UserProfiles.json");

                    List<UserModel> users = JsonConvert.DeserializeObject<List<UserModel>>(userProfileContent);
                    users.Add(user);
                    File.WriteAllText(userProfilePath, JsonConvert.SerializeObject(users));
                }
                else
                {
                    return "FAILURE";
                }
            }
            else
            {  
                using (StreamWriter writer = new StreamWriter(userProfilePath))
                {
                    writer.WriteLine(JsonConvert.SerializeObject(new List<UserModel>() { user }));
                    writer.Flush();
                    writer.Close();
                }
            }

            return "SUCCESS";
        }

        public bool SignExistingUserToSystem(UserModel user)
        {
            return CheckIfUserExist(user.UserName, user.Password) == "EXIST";
        }


        private string CheckIfUserExist(string userName, string passWord)
        {
            string userProfileContent = File.ReadAllText(ConfigurationManager.AppSettings["ResourcePath"] + @"\Resources\User Data\Profile\" + "UserProfiles.json");

            if (string.IsNullOrEmpty(userProfileContent))
            {
                return "NOTEXIST";
            }
            else
            {
                List<UserModel> users = JsonConvert.DeserializeObject<List<UserModel>>(userProfileContent);
                return users.Exists(item => item.UserName == userName && item.Password == passWord) ? "EXIST" : "NOTEXIST";
            }
        }
    }
}
