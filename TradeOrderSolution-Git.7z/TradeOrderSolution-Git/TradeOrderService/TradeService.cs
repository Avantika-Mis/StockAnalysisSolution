﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using TradeOrderService.Helper;

namespace TradeOrderService
{
    /// <summary>
    /// Trade class to expose methods needed for Trade related operations.
    /// </summary>
    public class TradeService : ITrade
    {
        public void FillStockInfo()
        {
            TradeAPIConsumer trd = new TradeAPIConsumer();
            var stockSymbols = SymbolContainer.GetAllSymbols();
            foreach (var symbol in stockSymbols)
            {
                try
                {
                    StockContainer.TradeCollection.TryAdd(symbol,
                    trd.GetStockReaLTimeInfoFromLocal(symbol));
                    Console.WriteLine("Fetched market data for symbol " + symbol);
                }
                catch(Exception)
                {
                    Console.WriteLine("Error while fetching information for symbol " + symbol);
                }
            }
        }

        public ConcurrentDictionary<string, List<StockModel>> GetAllStocks()
        {
            return StockContainer.TradeCollection;
        }     
    }
}
