﻿using System;
using System.ServiceModel;
using System.ServiceModel.Description;
using TradeOrderBookPresentation.TradeBL;
using TradeOrderService;

namespace TradeServiceConsoleHost
{
    internal class Program
    {
        static void Main(string[] args)
        {
            ServiceHost tradeServiceHost;
            ServiceHost userRegistrationHost;
            ServiceHost serviceUserTradeServiceHost;
            try
            {
                //Base Address for StudentService
                Uri httpTradeServiceBaseAddress = new Uri("http://localhost:4321/TradeService");
                Uri httpUserServiceBaseAddress = new Uri("http://localhost:4322/UserService");
                Uri httpUserTradeServiceBaseAddress = new Uri("http://localhost:4323/UserTradeService");

                tradeServiceHost = HostTradeService(httpTradeServiceBaseAddress);
                userRegistrationHost = HostUserRegistrationService(httpUserServiceBaseAddress);
                serviceUserTradeServiceHost = HostUserTradeService(httpUserTradeServiceBaseAddress);

                Console.WriteLine("Service is fetching stock data. Please wait...!");

                FillStockInfo();

                Console.WriteLine("Trade Service is live now at : {0}", httpTradeServiceBaseAddress);
                Console.WriteLine("User Registration Service is live now at : {0}", httpUserServiceBaseAddress);
                Console.WriteLine("User Trade Transaction Service is live now at : {0}", httpUserTradeServiceBaseAddress);

                Console.ReadKey();
            }

            catch (Exception ex)
            {
                Console.WriteLine("There is an issue with Market Service" + ex.Message);
            }
        }


        /// <summary>
        /// Host Trade Service.
        /// </summary>
        /// <param name="httpBaseAddress"></param>
        /// <returns></returns>
        private static ServiceHost HostTradeService(Uri httpBaseAddress)
        {
            //Instantiate ServiceHost
            ServiceHost tradeServiceHost = new ServiceHost(typeof(TradeOrderService.TradeService),
                httpBaseAddress);

            //Add Endpoint to Host
            tradeServiceHost.AddServiceEndpoint(typeof(TradeOrderService.ITrade),
                                                    new WSHttpBinding(), "");

            //Metadata Exchange
            ServiceMetadataBehavior serviceBehavior = new ServiceMetadataBehavior
            {
                HttpGetEnabled = true
            };
            tradeServiceHost.Description.Behaviors.Add(serviceBehavior);

            //Open
            tradeServiceHost.Open();
            return tradeServiceHost;
        }


        /// <summary>
        /// Host Trade Service.
        /// </summary>
        /// <param name="httpBaseAddress"></param>
        /// <returns></returns>
        private static ServiceHost HostUserRegistrationService(Uri httpBaseAddress)
        {
            //Instantiate ServiceHost
            ServiceHost userRegistrationServiceHost = new ServiceHost(typeof(TradeOrderService.UserService),
                httpBaseAddress);

            //Add Endpoint to Host
            userRegistrationServiceHost.AddServiceEndpoint(typeof(TradeOrderService.IRegistrationService), new WSHttpBinding(), "");

            //Metadata Exchange
            ServiceMetadataBehavior serviceBehavior = new ServiceMetadataBehavior
            {
                HttpGetEnabled = true
            };
            userRegistrationServiceHost.Description.Behaviors.Add(serviceBehavior);

            //Open
            userRegistrationServiceHost.Open();
            return userRegistrationServiceHost;
        }

        /// <summary>
        /// Host Trade Service.
        /// </summary>
        /// <param name="httpBaseAddress"></param>
        /// <returns></returns>
        private static ServiceHost HostUserTradeService(Uri httpBaseAddress)
        {
            //Instantiate ServiceHost
            ServiceHost tradeUserServiceHost = new ServiceHost(typeof(TradeOrderService.UserTradeService),
                httpBaseAddress);

            //Add Endpoint to Host
            tradeUserServiceHost.AddServiceEndpoint(typeof(TradeOrderService.IUserTradeService),
                                                    new WSHttpBinding(), "");

            //Metadata Exchange
            ServiceMetadataBehavior serviceBehavior = new ServiceMetadataBehavior
            {
                HttpGetEnabled = true
            };
            tradeUserServiceHost.Description.Behaviors.Add(serviceBehavior);

            //Open
            tradeUserServiceHost.Open();
            return tradeUserServiceHost;
        }

        /// <summary>
        /// Fill Stock Info
        /// </summary>
        private static void FillStockInfo()
        {
            TradeService trade = new TradeService();
            trade.FillStockInfo();
        }
    }
}
